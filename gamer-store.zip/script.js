
$(function(){
 $('.comprar').click(function(){
   alert('Produto adicionado ao carrinho!');
 });
});
